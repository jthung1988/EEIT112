package tw.DinBanDon.Filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/LoginPage.jsp")
public class CookieLogin implements Filter {

	public CookieLogin() {
		// TODO Auto-generated constructor stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		Cookie[] cookies = req.getCookies();
		String userId = "", userPwd = "", auto = "";
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("id")) {
					userId = cookie.getValue();
				} else if (cookie.getName().equals("pwd")) {
					userPwd = cookie.getValue();
				} else if (cookie.getName().equals("auto")) {
					auto = cookie.getValue();
				}
			}
			if(req.getSession(false) != null) {
				req.changeSessionId();
			}
			
			req.setAttribute("userId", userId);
			req.setAttribute("userPwd", userPwd);
			req.setAttribute("auto", auto);
		}
		chain.doFilter(req, res);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
