package tw.DinBanDon.Servlet;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;
import tw.DinBanDon.JavaBean.DinBanDonJavaBean;
import tw.DinBanDon.JavaBean.Meal;

@WebServlet("/ManagerServlet")
public class ManagerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
		LinkedList<DinBanDonJavaBean> dbdlist = new LinkedList<DinBanDonJavaBean>();
		LinkedList<Meal> menu = new LinkedList<Meal>();
		LinkedList<String> errorMsg = new LinkedList<String>();
		dbd.createConn();
		dbdlist = dbd.queryOrderToday();
		menu = dbd.getTodaysMenu();
		if (menu == null || menu.isEmpty()) {
			dbd.setMenu();
			menu = dbd.getTodaysMenu();
			if (menu == null) {
				errorMsg.add("No Menu Exception.");
			}
		}
		dbd.closeConn();
		if (errorMsg.size() == 0) {
			request.setAttribute("dbdlist", dbdlist);
			request.setAttribute("menu", menu);
			RequestDispatcher rd = request.getRequestDispatcher("ManagerPage.jsp");
			try {
				rd.forward(request, response);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			try {
				response.sendRedirect("ErrorPage/NoMenuError.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
