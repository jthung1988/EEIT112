package tw.DinBanDon.Servlet;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;
import tw.DinBanDon.JavaBean.Meal;

@WebServlet("/NewMealServlet")
public class NewMealServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request,response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		String mealId = request.getParameter("mealId");
		String mealContent = request.getParameter("mealContent");
		String strMealPrice = request.getParameter("mealPrice");
		LinkedList<Meal> menulist = new LinkedList<Meal>();
		LinkedList<String> errorMsg = new LinkedList<String>();
		try {
			int mealPrice =  Integer.parseInt(strMealPrice);
			DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
			menulist = dbd.getTodaysMenu();
			//========================
			for(Meal meal:menulist) {
				if(meal.getMealPK().getmealId().equals(mealId)) {
					errorMsg.add("Meal ID has been existed.");
					break;
				}
			}
			if(errorMsg.size() == 0) {
				dbd.newMeal(mealId, mealContent, mealPrice);
				request.getRequestDispatcher("/ManagerServlet").forward(request, response);;
				
			}else {
				response.sendRedirect("ErrorPage/MealExist.jsp");
			}
		}catch(Exception e){
			try {
				response.sendRedirect("ErrorPage/NewMealError.jsp");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			};
		}
		
	}

}
