package tw.DinBanDon.Servlet;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;
import tw.DinBanDon.JavaBean.Meal;

@WebServlet("/UserPageServlet")
public class UserPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		LinkedList<Meal> menulist = new LinkedList<Meal>();
		HttpSession session = request.getSession();
		LinkedList<String> errorMsg = new LinkedList<String>();

		DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
		if ((menulist = dbd.getTodaysMenu()) == null) {
			dbd.setMenu();
			menulist = dbd.getTodaysMenu();
			if (menulist == null || menulist.size() == 0) {
				errorMsg.add("No Menu Exception.");
			}
		}

		try {
			if (errorMsg.size() == 0) {
				session.setAttribute("menulist", menulist);
				RequestDispatcher rd = request.getRequestDispatcher("UserPage.jsp");
				rd.forward(request, response);
			}else {
				response.sendRedirect("ErrorPage/NoMenuError.jsp");
			}

		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
