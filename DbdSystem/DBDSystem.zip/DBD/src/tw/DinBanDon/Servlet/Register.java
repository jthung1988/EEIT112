package tw.DinBanDon.Servlet;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;


@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Pattern pUserId = Pattern.compile("^eeit112[0-9]{2}$");
	Pattern pUserPwd = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*{6,}$");
	Pattern pUserName = Pattern.compile("^[\u4E00-\u9FFF]{2,}$");
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId = request.getParameter("userId");
		String userName = request.getParameter("userName");
		String userPwd = request.getParameter("userPwd");
		String checkPwd = request.getParameter("checkPwd");
		Matcher macthId = pUserId.matcher(userId);
		Matcher macthPwd = pUserPwd.matcher(userPwd);
		Matcher macthName = pUserName.matcher(userName);
		
		if(!macthId.matches() || !macthName.matches()|| !macthPwd.matches() || !userPwd.equals(checkPwd)) {
			request.setAttribute("errorMsg", "User ID or Name or Password is not correct");
			RequestDispatcher rd = request.getRequestDispatcher("ErrorPage/LoginErrorPage.jsp");
			rd.forward(request, response);
		}else {
			DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
			if(dbd.findUserById(userId).getUserName() != null) {
				request.setAttribute("errorMsg", "The User ID Has Existed");
				RequestDispatcher rd = request.getRequestDispatcher("ErrorPage/LoginErrorPage.jsp");
				rd.forward(request, response);
			}else{
				dbd.newUser(userId,userName,userPwd);
				HttpSession session = request.getSession();
				session.setAttribute("userId", userId);
				session.setAttribute("userName", userName);
				session.setMaxInactiveInterval(60*60);
				RequestDispatcher rd = request.getRequestDispatcher("UserPageServlet");
				rd.forward(request, response);
			};
		}
	}
}
