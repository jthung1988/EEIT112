package tw.DinBanDon.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;

@WebServlet("/PayServlet")
public class PayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request,response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String userId = request.getParameter("userId");
		String orderDate = request.getParameter("orderDate");
		DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
		dbd.createConn();
		dbd.doPay(userId, orderDate);
		dbd.closeConn();
		try {
			response.sendRedirect("ManagerServlet");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
