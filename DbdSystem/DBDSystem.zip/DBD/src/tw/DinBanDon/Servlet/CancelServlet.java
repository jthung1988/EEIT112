package tw.DinBanDon.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.DinBanDon.DataBase.DbdDaoService;


@WebServlet("/CancelServlet")
public class CancelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processAction(request,response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response) {
		DbdDaoService dbd = new DbdDaoService();
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userId");
		String thisOrderDate = request.getParameter("cancel");
				//(String)session.getAttribute("thisOrderDate");
		dbd.deleteOrder(userId,thisOrderDate);
		try {
			response.sendRedirect("CancelOrderView.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
