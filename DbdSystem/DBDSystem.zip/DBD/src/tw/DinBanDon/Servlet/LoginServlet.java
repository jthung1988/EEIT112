package tw.DinBanDon.Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.DinBanDon.DataBase.DbdDaoJdbcImpl;
import tw.DinBanDon.JavaBean.DinBanDonJavaBean;

@WebServlet("/LoginServlet.do")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String userName;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processAction(request, response);
	}

	private void processAction(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userId = request.getParameter("userId");
		String userPwd = request.getParameter("userPwd");

		boolean result = false;
		if (userId == null || userId.length() == 0 || userPwd == null || userPwd.length() == 0) {

		} else {
			DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
			DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
			dbd.createConn();
			if ((dbdData = dbd.findUserById(userId)) != null) {
				int salt = dbd.getSalt(userId);
				if (salt == 0) {
					System.out.println("ERROR! UserId:" + userId + "'s salt is Wrong!");
				} else {
					if (dbdData.getUserPwd().equals(String.valueOf(userPwd.hashCode() * salt))) {
						userName = dbdData.getUserName();
						result = true;
					}
				}
			}
			dbd.closeConn();
		}

		if (result) {
			HttpSession session = request.getSession();
			session.setAttribute("userId", userId);
			session.setAttribute("userName", userName);
			session.setMaxInactiveInterval(60 * 60);

			// remember me
			if (request.getParameter("auto") != null) {
				session.setMaxInactiveInterval(60 * 60 * 24 * 7);
				Cookie cooId = new Cookie("id", userId);
				Cookie cooPwd = new Cookie("pwd", userPwd);
				Cookie cooAuto = new Cookie("auto", "true");
				cooId.setMaxAge(60 * 60 * 24 * 7);
				cooPwd.setMaxAge(60 * 60 * 24 * 7);
				cooAuto.setMaxAge(60 * 60 * 24 * 7);
				cooId.isHttpOnly();
				cooPwd.isHttpOnly();
				response.addCookie(cooId);
				response.addCookie(cooPwd);
				response.addCookie(cooAuto);

			}
			//
			if (userId.equals("eeit11200")) {
				RequestDispatcher rd = request.getRequestDispatcher("ManagerServlet");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("UserPageServlet");
				rd.forward(request, response);
			}

		} else {
			request.setAttribute("errorMsg", "User Name or Password is not correct.\nPlease Check Again!");
			RequestDispatcher rd = request.getRequestDispatcher("ErrorPage/LoginErrorPage.jsp");
			rd.forward(request, response);
		}
	}

//	private boolean checkUser(String userId, String pwd) {
//		boolean result = false;
//		if (userId == null || userId.length() == 0 || pwd == null || pwd.length() == 0) {
//			return result;
//		} else {
//			DbdDaoJdbcImpl dbd = new DbdDaoJdbcImpl();
//			DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
//			dbd.createConn();
//			if ((dbdData = dbd.findUserById(userId)) != null) {
//				int salt = dbd.getSalt(userId);
//				if (salt == 0) {
//					System.out.println("UserId:" + userId + "'s salt is Wrong!");
//				}
//				userName = dbdData.getUserName();
//				result = true;
//			}
//			dbd.closeConn();
//		}
//		return result;
//	}

}
