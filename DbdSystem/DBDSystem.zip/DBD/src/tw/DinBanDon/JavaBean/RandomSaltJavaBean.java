package tw.DinBanDon.JavaBean;

import javax.persistence.*;

@Entity
@Table(name = "randomSalt")
public class RandomSaltJavaBean {
	@Id
	@Column(name = "userId")
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "profile", cascade = CascadeType.ALL)
	private String userId;
	
	
	@Column(name = "salt")
	private int salt;
	
	private ProfileJavaBean ProfileJavaBean;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getSalt() {
		return salt;
	}

	public void setSalt(int salt) {
		this.salt = salt;
	}

	public ProfileJavaBean getProfileJavaBean() {
		return ProfileJavaBean;
	}

	public void setProfileJavaBean(ProfileJavaBean profileJavaBean) {
		ProfileJavaBean = profileJavaBean;
	}

	
}
