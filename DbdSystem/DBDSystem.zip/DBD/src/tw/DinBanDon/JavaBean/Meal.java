package tw.DinBanDon.JavaBean;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name = "mealList")
public class Meal implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "mealId")
	private String mealId;
	
	@Column(name = "mealContent")
	private String mealContent;
	
	@Column(name = "mealPrice")
	private int mealPrice;
	
	@Column(name = "mealDate")
	private String mealDate;

	public String getMealId() {
		return mealId;
	}
	
	public void setMealId(String mealId) {
		this.mealId = mealId;
	}

	public String getMealContent() {
		return mealContent;
	}

	public void setMealContent(String mealContent) {
		this.mealContent = mealContent;
	}

	public int getMealPrice() {
		return mealPrice;
	}

	public void setMealPrice(int mealPrice) {
		this.mealPrice = mealPrice;
	}

}
