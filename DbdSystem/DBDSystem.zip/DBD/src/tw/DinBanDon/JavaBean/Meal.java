package tw.DinBanDon.JavaBean;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "mealList")
public class Meal implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "mealId")
	private String mealId;
	
	@Column(name = "mealContent")
	private String mealContent;
	
	@Column(name = "mealPrice")
	private int mealPrice;
	
	@Id
	@Column(name = "mealDate")
	private String mealDate;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "mealList", cascade = CascadeType.ALL)
	private Set<OrderList> oderSet = new HashSet<OrderList>(); 

	public String getMealId() {
		return mealId;
	}
	
	public void setMealId(String mealId) {
		this.mealId = mealId;
	}

	public String getMealContent() {
		return mealContent;
	}

	public void setMealContent(String mealContent) {
		this.mealContent = mealContent;
	}

	public int getMealPrice() {
		return mealPrice;
	}

	public void setMealPrice(int mealPrice) {
		this.mealPrice = mealPrice;
	}

	public String getMealDate() {
		return mealDate;
	}

	public void setMealDate(String mealDate) {
		this.mealDate = mealDate;
	}

	public Set<OrderList> getOderSet() {
		return oderSet;
	}

	public void setOderSet(Set<OrderList> oderSet) {
		this.oderSet = oderSet;
	}

}
