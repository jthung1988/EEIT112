package tw.DinBanDon.JavaBean;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

@Embeddable
public class MealPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "mealId")
    private String mealId;
 
    @Column(name = "mealDate")
    private String mealDate;
 
    public MealPK() {
    }
 
    public MealPK(String mealId, String mealDate) {
        this.mealId = mealId;
        this.mealDate = mealDate;
    }
 
    public String getmealId() {
        return mealId;
    }
 
    public String getmealDate() {
        return mealDate;
    }
 
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MealPK)) return false;
        MealPK that = (MealPK) o;
        return Objects.equals(getmealId(), that.getmealId()) &&
                Objects.equals(getmealDate(), that.getmealDate());
    }
 
    @Override
    public int hashCode() {
        return Objects.hash(getmealId(), getmealDate());
    }
}
