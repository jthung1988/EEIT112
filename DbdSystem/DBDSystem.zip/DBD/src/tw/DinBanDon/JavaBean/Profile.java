package tw.DinBanDon.JavaBean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "profile")
public class Profile {
	@Id
	@Column(name = "userId")
	private String userId;
	
	@Column(name = "userName")
	private String userName;
	
	@Column(name = "userPwd")
	private String userPwd;
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "profile", cascade = CascadeType.ALL)
	private RandomSalt randomSalt;
	
//	@OneToMany(fetch = FetchType.LAZY, mappedBy = "profile", cascade = CascadeType.ALL)
//	private Set<OrderList> orderList = new HashSet<OrderList>(0);

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public RandomSalt getRandomSalt() {
		return randomSalt;
	}

	public void setRandomSalt(RandomSalt randomSalt) {
		this.randomSalt = randomSalt;
	}
//
//	public Set<OrderList> getOrderList() {
//		return orderList;
//	}
//
//	public void setOrderList(Set<OrderList> orderList) {
//		this.orderList = orderList;
//	}



}
