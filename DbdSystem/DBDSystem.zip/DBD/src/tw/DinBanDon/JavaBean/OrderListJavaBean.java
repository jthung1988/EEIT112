package tw.DinBanDon.JavaBean;

import java.util.LinkedList;

import javax.persistence.*;
@Entity
@Table(name = "orderlist")
public class OrderListJavaBean {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "orderId")
	private int orderId;
	
	@Column(name = "userId")
	private String userId;
	
	@Column(name = "mealId")
	private String mealId;
	
	@Column(name = "mealDate")
	private String mealDate;
	
	@Column(name = "orderDate")
	private String orderDate;
	
	@Column(name = "orderPayFlag")
	private boolean orderPayFlag;
	
	@Column(name = "orderNote")
	private String orderNote;
	
	private LinkedList<OrderListJavaBean> oderlist = new LinkedList<OrderListJavaBean>();

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMealId() {
		return mealId;
	}

	public void setMealId(String mealId) {
		this.mealId = mealId;
	}

	public String getMealDate() {
		return mealDate;
	}

	public void setMealDate(String mealDate) {
		this.mealDate = mealDate;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public boolean isOrderPayFlag() {
		return orderPayFlag;
	}

	public void setOrderPayFlag(boolean orderPayFlag) {
		this.orderPayFlag = orderPayFlag;
	}

	public String getOrderNote() {
		return orderNote;
	}

	public void setOrderNote(String orderNote) {
		this.orderNote = orderNote;
	}

	public LinkedList<OrderListJavaBean> getOderlist() {
		return oderlist;
	}

	public void setOderlist(LinkedList<OrderListJavaBean> oderlist) {
		this.oderlist = oderlist;
	}

}
