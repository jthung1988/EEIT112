package tw.DinBanDon.JavaBean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "orderList")
public class OrderList {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "orderId")
	private int orderId;

//	@Column(name = "o_mealId")
//	private String mealId;
//	
//	@Column(name = "o_mealDate")
//	private String mealDate;
	
	@Column(name = "orderDate")
	private String orderDate;
	
	@Column(name = "orderPayFlag")
	private boolean orderPayFlag;
	
	@Column(name = "orderNote")
	private String orderNote;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userId")
	private Profile profile;
	
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ 
//			@JoinColumn(name="mealId"),
//	        @JoinColumn(name="mealDate")})
//	private Meal meal;
	
//	private LinkedList<OrderList> oderlist = new LinkedList<OrderList>();

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

//	public String getMealId() {
//		return mealId;
//	}
//
//	public void setMealId(String mealId) {
//		this.mealId = mealId;
//	}
//
//	public String getMealDate() {
//		return mealDate;
//	}
//
//	public void setMealDate(String mealDate) {
//		this.mealDate = mealDate;
//	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public boolean isOrderPayFlag() {
		return orderPayFlag;
	}

	public void setOrderPayFlag(boolean orderPayFlag) {
		this.orderPayFlag = orderPayFlag;
	}

	public String getOrderNote() {
		return orderNote;
	}

	public void setOrderNote(String orderNote) {
		this.orderNote = orderNote;
	}

//	public LinkedList<OrderList> getOderlist() {
//		return oderlist;
//	}
//
//	public void setOderlist(LinkedList<OrderList> oderlist) {
//		this.oderlist = oderlist;
//	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

//	public Meal getMeal() {
//		return meal;
//	}
//
//	public void setMeal(Meal meal) {
//		this.meal = meal;
//	}

}
