package tw.DinBanDon.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import tw.DinBanDon.JavaBean.Meal;
import tw.DinBanDon.JavaBean.MealPK;

public class MealDao {
	private Session session;

	public MealDao() {
	}

	public MealDao(Session session) {
		this.session = session;
	}

	public Meal insertMeal(Meal meal) {
		Meal mb = session.get(Meal.class, meal.getMealPK());
		if(mb==null) {
			session.save(meal);
			return meal;
		}
		return null;
	}
	
	public Meal updateMeal(MealPK pk, String Content, int price) {
		Meal rs = session.get(Meal.class, pk);
		if(rs != null) {
			rs.setMealContent(Content);
			rs.setMealPrice(price);
			return rs;
		}else
			return null;
	}
	
	public  boolean deleteMeal(MealPK pk) {
		Meal rs = session.get(Meal.class, pk);
		if(rs != null) {
			session.delete(rs);
			return true;
		}else
			return false;
	}
	
	public Meal queryMeal(MealPK pk) {
		return session.get(Meal.class, pk);
	}
	
	public List<Meal> queryAll(){
		Query<Meal> queryMeal = session.createQuery("from Meal",Meal.class);
		List<Meal> mealList = queryMeal.list();
		return mealList;
	}
}
