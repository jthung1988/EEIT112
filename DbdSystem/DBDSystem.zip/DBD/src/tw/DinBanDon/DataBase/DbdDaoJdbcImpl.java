package tw.DinBanDon.DataBase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import tw.DinBanDon.HibernateUtil.HibernateUtil;
import tw.DinBanDon.JavaBean.DinBanDonJavaBean;
import tw.DinBanDon.JavaBean.Meal;
import tw.DinBanDon.JavaBean.MealPK;
import tw.DinBanDon.JavaBean.OrderList;
import tw.DinBanDon.JavaBean.Profile;
import tw.DinBanDon.JavaBean.RandomSalt;

public class DbdDaoJdbcImpl implements IDbdDao {
	String driversrc = "";
	private Session session;

	public DbdDaoJdbcImpl() {
		this.driversrc = "C:/GitHub/chromedriver.exe";
		session = HibernateUtil.getFactory().getCurrentSession();
	}

	public DbdDaoJdbcImpl(String driver) {
		this.driversrc = driver;
	}

	public DinBanDonJavaBean findUserById(String userId) {
		Profile user = session.get(Profile.class, userId);
		DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
		if (user != null) {
			dbdData.setUserId(userId);
			dbdData.setUserName(user.getUserName());
			dbdData.setUserPwd(user.getUserPwd());
		}
		return dbdData;
	}

	public int getSalt(String userId) {
		RandomSalt salt = session.get(RandomSalt.class, userId);
		return salt.getSalt();
	}

	public void newUser(String userId, String userName, String userPwd) {
		Profile profile = new Profile();
		profile.setUserId(userId);
		profile.setUserName(userName);
		int salt = (int) (Math.random() * 100) + 1;
		int hcPwd = userPwd.hashCode() * salt;
		profile.setUserPwd(String.valueOf(hcPwd));
		RandomSalt saltBean = new RandomSalt();
		saltBean.setSalt(salt);
		profile.setRandomSalt(saltBean);
		saltBean.setProfile(profile);
		session.save(profile);
	}

	public void newOrder(String userId, String mealId) {
		OrderList orderList = new OrderList();
		orderList.setUserId(userId);
		orderList.setMealId(mealId);
		orderList.setMealDate(getDate());
		orderList.setOrderDate(getDateTime());
		session.save(orderList);
	}

	public LinkedList<DinBanDonJavaBean> queryOrderByUID(String userId) {
		String hql = "FROM OrderList AS ol, Profile AS p, Meal AS m "
				+ "WHERE ol.mealId = m.mealPK.mealId "
				+ "AND p.userId = ol.userId "
				+ "AND m.mealPK.mealDate = ?1"
				+ "AND ol.userId = ?2";
		Query<Object[]> query = session.createQuery(hql,Object[].class);
		query.setParameter(1, getDate());
		query.setParameter(2, userId);
		LinkedList<DinBanDonJavaBean> dbdlist = new LinkedList<DinBanDonJavaBean>();
		List<Object[]> queryList = query.list();
//		JSONArray jarray = new JSONArray();
		
		OrderList o;
		Profile p;
		Meal m;
		
		for (Object[] result : queryList) {
			o = (OrderList)result[0];
			p = (Profile)result[1];
			m = (Meal)result[2];
			DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
			dbdData.setUserId(p.getUserId());
			dbdData.setUserName(p.getUserName());
			dbdData.setMealId(o.getMealId());
			dbdData.setMealContent(m.getMealContent());
			dbdData.setMealPrice(m.getMealPrice());
			dbdData.setOrderPayFlag(o.isOrderPayFlag());
			dbdData.setOrderDate(o.getOrderDate());
			dbdlist.add(dbdData);
//			JSONObject jobj = new JSONObject();
//			jobj.append("userId", p.getUserId());
//			jobj.append("userName", p.getUserName());
//			jobj.append("mealId", m.getMealPK().getmealId());
//			jobj.append("mealContent", m.getMealContent());
//			jobj.append("mealPrice", m.getMealPrice());
//			jobj.append("orderDate", o.getOrderDate());
//			jobj.append("orderPayFlag", o.isOrderPayFlag());
//			jarray.put(jobj);
		}
		return dbdlist;
	}

	public LinkedList<DinBanDonJavaBean> queryOrderToday() {
		String hql = "FROM OrderList ol,Profile p, Meal m "
				+ "where ol.mealId = m.mealPK.mealId "
				+ "AND p.userId = ol.userId "
				+ "AND m.mealPK.mealDate=:day";
		Query<Object[]> query = session.createQuery(hql,Object[].class);
		query.setParameter("day", getDate());
		LinkedList<DinBanDonJavaBean> dbdlist = new LinkedList<DinBanDonJavaBean>();
		List<Object[]> queryList = query.list();
//		JSONArray jarray = new JSONArray();
		
		OrderList o;
		Profile p;
		Meal m;
		for (Object[] result : queryList) {
			o = (OrderList)result[0];
			p = (Profile)result[1];
			m = (Meal)result[2];
			DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
			dbdData.setUserId(p.getUserId());
			dbdData.setUserName(p.getUserName());
			dbdData.setMealId(o.getMealId());
			dbdData.setMealContent(m.getMealContent());
			dbdData.setMealPrice(m.getMealPrice());
			dbdData.setOrderPayFlag(o.isOrderPayFlag());
			dbdData.setOrderDate(o.getOrderDate());
			dbdlist.add(dbdData);
		}
		return dbdlist;
	}

	public void deleteOrder(String userId, String orderDate) {
		Query<OrderList> query = session.createQuery("from OrderList where userId=:userId AND orderDate=:orderDate",OrderList.class);
		query.setParameter("userId", userId);
		query.setParameter("orderDate", orderDate);
		List<OrderList> orderlist = query.list();
		if(orderlist.size()==1) {
			session.delete(orderlist.get(0));
		}
	}

	public void doPay(String userId, String orderDate) {
		Query<OrderList> query = session.createQuery("from OrderList where userId=:userId AND orderDate=:orderDate",OrderList.class);
		query.setParameter("userId", userId);
		query.setParameter("orderDate", orderDate);
		List<OrderList> orderlist = query.list();
		if(orderlist.size()==1) {
			orderlist.get(0).setOrderPayFlag(true);
		}
	}

	public LinkedList<Meal> getTodaysMenu() {
		Query<Meal> query = session.createQuery("from Meal where mealDate=:mealDate",Meal.class);
		List<Meal> mealList = query.setParameter("mealDate", getDate()).list();
		LinkedList<Meal> menu = new LinkedList<Meal>();
		if(mealList.size()>0) {
			for(Meal meal:mealList) {
				menu.add(meal);
			}
			return menu;
		}else {
			return null;
		}
	}

	public void setMenu() {
		String sourceURL = "http://stroe.tagfans.com/#page_join?o=8301&id=36055"; // Menu Source Address
		System.setProperty("webdriver.chrome.driver", driversrc);

		LinkedList<String> menulist = new LinkedList<String>();
		
		// Get Menu Data
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(true);
		WebDriver driver = new ChromeDriver(options);
		driver.get(sourceURL);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("menu_item")));
			Document doc = Jsoup.parse(driver.getPageSource());
			driver.close();
			Elements ids = doc.select(".option_name");
			Elements price = doc.select(".option_price");
			String mealstr;
			for (int i = 0; i < ids.size(); i++) {
				mealstr = ids.eq(i).text() + "#" + price.eq(i).text();
				menulist.add(mealstr);
			}
			// Insert to Database
			String[] mealData;
			Character mealid = 'A';
			for (String meal : menulist) {
				System.out.println("before:" + mealid);
				MealPK pk = new MealPK(String.valueOf(mealid++), getDate());
				Meal mealBean = new Meal();
				System.out.println("after" + mealid);
				mealData = meal.split("#");
				mealBean.setMealPK(pk);
				mealBean.setMealContent(mealData[0]);
				mealBean.setMealPrice(Integer.parseInt(mealData[1]));
				session.save(mealBean);
			}
		} catch (Exception e) {
			System.out.println("Error:" + e.getMessage());
		}

	}

	public void newMeal(String mealId, String mealContent, int price) {
		Meal result = session.get(Meal.class, new MealPK(mealId,getDate()));
		if(result ==null) {
			Meal meal = new Meal();
			meal.setMealPK(new MealPK(mealId, getDate()));
			meal.setMealContent(mealContent);
			meal.setMealPrice(price);
			session.save(meal);
		}
	}

	public String getDateTime() {
		String datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date().getTime());
		return datetime;
	}

	public String getDate() {
		String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
		return date;
	}
}
