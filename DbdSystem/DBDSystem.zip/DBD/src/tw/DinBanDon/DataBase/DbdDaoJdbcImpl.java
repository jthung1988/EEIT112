package tw.DinBanDon.DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import tw.DinBanDon.JavaBean.DinBanDonJavaBean;
import tw.DinBanDon.JavaBean.Meal;

public class DbdDaoJdbcImpl implements IDbdDao {
	private Connection conn;
	String driversrc = "";

	public DbdDaoJdbcImpl() {
		this.driversrc = "C:/GitHub/chromedriver.exe";
	}
	
	public DbdDaoJdbcImpl(String driver) {
		this.driversrc = driver;
	}

	public boolean getConnStatus() {
		boolean isConn = false;
		try {
			isConn = !conn.isClosed();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isConn;
	}

	public void createConn() {
		try {
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:comp/env/ConnSqlServerJdbc/DinBanDonSystem");
			conn = ds.getConnection();
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void closeConn() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public DinBanDonJavaBean findUserById(String userId) {
		DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
		String sqlstr = "SELECT * FROM Profile WHERE userId=?";
		String userName = "", hsPwd = "";

		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			ResultSet rs = state.executeQuery();
			if (rs.next()) {
				userName = rs.getString("userName");
				hsPwd = rs.getString("userPwd");
				rs = state.executeQuery();
				if (rs.next()) {
					dbdData.setUserId(userId);
					dbdData.setUserName(userName);
					dbdData.setUserPwd(hsPwd);
				} else {
					dbdData = null;
				}
				rs.close();
				state.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbdData;
	}

	public int getSalt(String userId) {
		String sqlSalt = "SELECT * FROM RandomSalt WHERE userId=?";
		int salt = 0;
		PreparedStatement state;
		try {
			state = conn.prepareStatement(sqlSalt);
			state.setString(1, userId);
			ResultSet rs = state.executeQuery();
			if (rs.next()) {
				salt = rs.getInt("salt");
			}
			rs.close();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return salt;
	}

	public void newUser(String userId, String userName, String userPwd) {
		int salt = (int) (Math.random() * 100) + 1;
		int hcPwd = userPwd.hashCode() * salt;
		String sqlstr = "INSERT INTO Profile(userId,userName,userPwd) VALUES(?,?,?)";
		String sqlstr2 = "INSERT INTO RandomSalt(userId,salt) VALUES(?,?)";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			state.setString(2, userName);
			state.setString(3, String.valueOf(hcPwd));
			state.executeUpdate();
			state = conn.prepareStatement(sqlstr2);
			state.setString(1, userId);
			state.setInt(2, salt);
			state.executeUpdate();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void newOrder(String userId, String mealId) {
		String sqlstr = "INSERT INTO OrderList(userId,mealId,orderDate)VALUES(?,?,?)";
		String datetime = getDateTime();
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			state.setString(2, mealId);
			state.setString(3, datetime);
			state.executeUpdate();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public LinkedList<DinBanDonJavaBean> queryOrderByUID(String userId) {
		LinkedList<DinBanDonJavaBean> dbdlist = new LinkedList<DinBanDonJavaBean>();
		String sqlstr = "SELECT * FROM OrderList AS ol JOIN MealList AS ml ON ol.mealId = ml.mealId \r\n"
				+ "JOIN Profile AS p ON p.userId = ol.userId\r\n"
				+ "WHERE ol.userId=? AND ml.mealDate=? AND ol.orderDate>?";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			state.setString(2, getDate());
			state.setString(3, getDate());
			ResultSet rs = state.executeQuery();
			while (rs.next()) {
				DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
				dbdData.setUserId(rs.getString("userId"));
				dbdData.setUserName(rs.getString("userName"));
				dbdData.setMealId(rs.getString("mealId"));
				dbdData.setMealContent(rs.getString("mealContent"));
				dbdData.setMealPrice(rs.getInt("mealPrice"));
				dbdData.setOrderPayFlag(rs.getBoolean("orderPayFlag"));
				dbdData.setOrderDate(rs.getString("orderDate"));
				dbdlist.add(dbdData);
			}
			rs.close();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbdlist;
	}

	public LinkedList<DinBanDonJavaBean> queryOrderToday() {

		LinkedList<DinBanDonJavaBean> dbdlist = new LinkedList<DinBanDonJavaBean>();
		String sqlstr = "SELECT * FROM OrderList AS ol \r\n" + "JOIN MealList AS ml ON ol.mealId = ml.mealId \r\n"
				+ "JOIN Profile AS p ON p.userId = ol.userId\r\n" + "WHERE ol.orderDate>? AND ml.mealDate=?";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, getDate());
			state.setString(2, getDate());
			ResultSet rs = state.executeQuery();
			while (rs.next()) {
				DinBanDonJavaBean dbdData = new DinBanDonJavaBean();
				dbdData.setUserId(rs.getString("userId"));
				dbdData.setUserName(rs.getString("userName"));
				dbdData.setMealId(rs.getString("mealId"));
				dbdData.setMealContent(rs.getString("mealContent"));
				dbdData.setMealPrice(rs.getInt("mealPrice"));
				dbdData.setOrderPayFlag(rs.getBoolean("orderPayFlag"));
				dbdData.setOrderDate(rs.getString("orderDate"));
				dbdlist.add(dbdData);
			}
			rs.close();
			state.close();
			return dbdlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void deleteOrder(String userId, String thisOrderDate) {
		String sqlstr = "DELETE FROM OrderList WHERE userId = ? AND orderDate =?";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			state.setString(2, thisOrderDate);
			state.execute();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void doPay(String userId, String orderDate) {
		String sqlstr = "UPDATE OrderList SET orderPayFlag=1  WHERE userId = ? AND orderDate=?";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, userId);
			state.setString(2, orderDate);
			state.execute();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public LinkedList<Meal> getTodaysMenu() {
		String sqlstr = "SELECT * FROM MealList WHERE mealDate=?";
		;
		LinkedList<Meal> menulist = new LinkedList<Meal>();
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, getDate());
			ResultSet rs = state.executeQuery();

			while (rs.next()) {
				Meal mealData = new Meal();
				mealData.setMealId(rs.getString("mealId"));
				mealData.setMealContent(rs.getString("mealContent"));
				mealData.setMealPrice(rs.getInt("mealPrice"));
				menulist.add(mealData);
			}
			;
			rs.close();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (menulist.size() > 0)
			return menulist;
		return null;
	}

	public void setMenu() {
		String sqlstr = "INSERT INTO MealList(mealId,mealContent,mealPrice,mealDate)VALUES(?,?,?,?)";
		String sourceURL = "http://stroe.tagfans.com/#page_join?o=8301&id=36055"; // Menu Source Address
//		String driversrc = "D:/WorkSpace/JspSpace/chromedriver.exe"; // Chrome Driver Address
//		String driversrc = "C:/JspSpace/chromedriver.exe"; // Chrome Driver Address
		System.setProperty("webdriver.chrome.driver", driversrc);

		LinkedList<String> menulist = new LinkedList<String>();
		// Get Menu Data
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(true);
		WebDriver driver = new ChromeDriver(options);
		driver.get(sourceURL);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.className("menu_item")));
			Document doc = Jsoup.parse(driver.getPageSource());
			driver.close();

			Elements ids = doc.select(".option_name");
			// System.out.println("ids = " + ids.eq(0)); //TEST
			Elements price = doc.select(".option_price");
			String mealstr;
			for (int i = 0; i < ids.size(); i++) {
				mealstr = ids.eq(i).text() + "#" + price.eq(i).text();
				menulist.add(mealstr);
			}
			// Insert to Database
			String[] menuData;
			Character mealid = 'A';
			for (String menu : menulist) {
				menuData = menu.split("#");
				try {
					PreparedStatement state = conn.prepareStatement(sqlstr);
					state.setString(1, (mealid++).toString());
					state.setString(2, menuData[0]);
					state.setString(3, menuData[1]);
					state.setString(4, getDate());
					state.executeUpdate();
					state.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	}

	public void newMeal(String mealId, String mealContent, int price) {
		String sqlstr = "INSERT INTO MealList(mealId,mealContent,mealPrice,mealDate) VALUES(?,?,?,?)";
		try {
			PreparedStatement state = conn.prepareStatement(sqlstr);
			state.setString(1, mealId);
			state.setString(2, mealContent);
			state.setInt(3, price);
			state.setString(4, getDate());
			state.executeUpdate();
			state.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getDateTime() {
		String datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date().getTime());
		return datetime;
	}

	public String getDate() {
		String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
		return date;
	}
}
