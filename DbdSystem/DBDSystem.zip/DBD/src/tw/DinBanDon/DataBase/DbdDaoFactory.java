package tw.DinBanDon.DataBase;

public class DbdDaoFactory {
	public static IDbdDao getDbdDao() {
		IDbdDao dbd = new DbdDaoJdbcImpl();
		return dbd;
	}
}
