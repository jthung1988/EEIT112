package tw.DinBanDon.DataBase;

import java.util.LinkedList;

import tw.DinBanDon.JavaBean.DinBanDonJavaBean;
import tw.DinBanDon.JavaBean.Meal;

public class DbdDaoService {

	private IDbdDao dbd;

	public DbdDaoService() {
		dbd = new DbdDaoJdbcImpl();
	}

	public DinBanDonJavaBean findUserById(String userId) {
		return dbd.findUserById(userId);
	}

	public int getSalt(String userId) {
		return dbd.getSalt(userId);
	}

	public void newUser(String userId, String userName, String userPwd) {
		dbd.newUser(userId, userName, userPwd);
	}

	public void newOrder(String userId, String mealId) {
		dbd.newOrder(userId, mealId);
	}

	public LinkedList<DinBanDonJavaBean> queryOrderByUID(String userId) {
		return dbd.queryOrderByUID(userId);
	}

	public LinkedList<DinBanDonJavaBean> queryOrderToday() {
		return dbd.queryOrderToday();
	}

	public void deleteOrder(String userId, String thisOrderDate) {
		dbd.deleteOrder(userId, thisOrderDate);
	}

	public void doPay(String userId, String orderDate) {
		dbd.doPay(userId, orderDate);
	}

	public LinkedList<Meal> getTodaysMenu() {
		return getTodaysMenu();
	}

	public void setMenu() {
		dbd.setMenu();
	}

	public void newMeal(String mealId, String mealContent, int price) {
		dbd.newMeal(mealId, mealContent, price);
	}

	public String getDateTime() {
		return dbd.getDateTime();
	}

	public String getDate() {
		return dbd.getDate();
	}
}
