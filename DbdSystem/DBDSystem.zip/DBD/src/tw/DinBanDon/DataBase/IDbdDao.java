package tw.DinBanDon.DataBase;

import java.util.LinkedList;

import tw.DinBanDon.JavaBean.DinBanDonJavaBean;
import tw.DinBanDon.JavaBean.Meal;

public interface IDbdDao {
	DinBanDonJavaBean findUserById(String userId);
	int getSalt(String userId);
	void newUser(String userId, String userName, String userPwd);
	void newOrder(String userId, String mealId);
	LinkedList<DinBanDonJavaBean> queryOrderByUID(String userId);
	LinkedList<DinBanDonJavaBean> queryOrderToday();
	void deleteOrder(String userId, String thisOrderDate);
	void doPay(String userId, String orderDate);
	LinkedList<Meal> getTodaysMenu();
	void setMenu();
	void newMeal(String mealId, String mealContent, int price);
	String getDateTime();
	String getDate();
}
