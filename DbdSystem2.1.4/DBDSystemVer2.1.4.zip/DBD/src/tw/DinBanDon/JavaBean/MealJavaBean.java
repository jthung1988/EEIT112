package tw.DinBanDon.JavaBean;

import java.io.Serializable;

public class MealJavaBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String mealId;
	private String mealContent;
	private int mealPrice;

	public String getMealId() {
		return mealId;
	}

	public void setMealId(String mealId) {
		this.mealId = mealId;
	}

	public String getMealContent() {
		return mealContent;
	}

	public void setMealContent(String mealContent) {
		this.mealContent = mealContent;
	}

	public int getMealPrice() {
		return mealPrice;
	}

	public void setMealPrice(int mealPrice) {
		this.mealPrice = mealPrice;
	}

}
