package tw.DinBanDon.JavaBean;

import java.io.Serializable;

public class DinBanDonJavaBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String userId;
	private String userName;
	private String userPwd;
	private String mealId;
	private String orderDate;
	private boolean orderPayFlag;
	private String orderNote;
	private String mealContent;
	private int mealPrice;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getMealId() {
		return mealId;
	}
	public void setMealId(String mealId) {
		this.mealId = mealId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public boolean isOrderPayFlag() {
		return orderPayFlag;
	}
	public void setOrderPayFlag(boolean orderPayFlag) {
		this.orderPayFlag = orderPayFlag;
	}
	public String getOrderNote() {
		return orderNote;
	}
	public void setOrderNote(String orderNote) {
		this.orderNote = orderNote;
	}
	public String getMealContent() {
		return mealContent;
	}
	public void setMealContent(String mealContent) {
		this.mealContent = mealContent;
	}
	public int getMealPrice() {
		return mealPrice;
	}
	public void setMealPrice(int mealPrice) {
		this.mealPrice = mealPrice;
	}
	
	
	
}
